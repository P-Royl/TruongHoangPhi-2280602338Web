﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductApiController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        public ProductApiController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts(int page = 1, int pageSize = 10, string search = null)
        {
            try
            {
                // Get products with pagination and search from the repository
                var result = await _productRepository.GetProductsAsync(page, pageSize, search);

                // Calculate the total number of pages
                int totalItems = result.TotalItems;
                int totalPages = (int)Math.Ceiling((double)totalItems / pageSize);

                // Create the response object with pagination info
                var response = new
                {
                    data = result.Products,
                    pagination = new
                    {
                        currentPage = page,
                        pageSize = pageSize,
                        totalPages = totalPages,
                        totalItems = totalItems
                    }
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            try
            {
                var product = await _productRepository.GetProductByIdAsync(id);
                if (product == null)
                    return NotFound();
                return Ok(product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        // Change to accept 'multipart/form-data' to handle image upload
        [HttpPost]
        public async Task<IActionResult> AddProduct([FromForm] Product product, IFormFile image)
        {
            try
            {
                // Save the image and get the image URL
                if (image != null)
                {
                    var imageUrl = await _productRepository.SaveImageAsync(image);
                    product.ImageUrl = imageUrl;
                }

                // Add the product to the database
                await _productRepository.AddProductAsync(product);
                return CreatedAtAction(nameof(GetProductById), new { id = product.Id }, product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        // Change to accept 'multipart/form-data' for updating product with image
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromForm] Product product, IFormFile image)
        {
            try
            {
                if (id != product.Id)
                    return BadRequest();

                // If image is provided, save the new image and update the ImageUrl
                if (image != null)
                {
                    var imageUrl = await _productRepository.SaveImageAsync(image);
                    product.ImageUrl = imageUrl;
                }

                // Update the product in the database
                await _productRepository.UpdateProductAsync(product);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                await _productRepository.DeleteProductAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
