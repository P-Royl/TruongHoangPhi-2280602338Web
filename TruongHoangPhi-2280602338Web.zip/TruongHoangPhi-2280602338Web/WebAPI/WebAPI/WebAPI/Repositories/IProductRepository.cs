﻿using WebAPI.Models;

public interface IProductRepository
{
    Task<(List<Product> Products, int TotalItems)> GetProductsAsync(int page, int pageSize, string search);
    Task<Product?> GetProductByIdAsync(int id);
    Task AddProductAsync(Product product);
    Task UpdateProductAsync(Product product);
    Task DeleteProductAsync(int id);
    Task<string> SaveImageAsync(IFormFile image);
}
